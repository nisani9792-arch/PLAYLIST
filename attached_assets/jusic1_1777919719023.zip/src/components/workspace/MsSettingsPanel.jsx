import React from 'react';
import { X } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function MsSettingsPanel({ config, onChange, onClose }) {
  return (
    <div className="w-full max-w-3xl mx-auto mt-2">
      <Card className="p-4 space-y-3 bg-muted/30 border-dashed">
        <div className="flex items-center justify-between">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">הגדרות Meilisearch</p>
          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onClose}><X className="w-3.5 h-3.5" /></Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">כתובת שרת</label>
            <Input value={config.msUrl} onChange={e => onChange('msUrl', e.target.value)} placeholder="http://..." dir="ltr" className="font-mono text-xs" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">API Key</label>
            <Input value={config.msApiKey} onChange={e => onChange('msApiKey', e.target.value)} type="password" dir="ltr" className="font-mono text-xs" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">אינדקס</label>
            <Input value={config.msIndex} onChange={e => onChange('msIndex', e.target.value)} placeholder="music" dir="ltr" className="font-mono text-xs" />
          </div>
        </div>
      </Card>
    </div>
  );
}