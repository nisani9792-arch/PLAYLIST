import React, { useCallback, useState } from 'react';
import { Upload, FileCheck } from 'lucide-react';

export default function FileDropZone({ accept, onFile, label, sublabel, icon: CustomIcon }) {
  const [isDragging, setIsDragging] = useState(false);
  const [fileName, setFileName] = useState(null);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      setFileName(file.name);
      onFile(file);
    }
  }, [onFile]);

  const handleChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFileName(file.name);
      onFile(file);
    }
  };

  const Icon = fileName ? FileCheck : (CustomIcon || Upload);

  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={handleDrop}
      className={`relative border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-300 cursor-pointer group ${
        isDragging
          ? 'border-primary bg-primary/5 scale-[1.02]'
          : fileName
          ? 'border-primary/40 bg-primary/5'
          : 'border-border hover:border-primary/40 hover:bg-accent/50'
      }`}
    >
      <input
        type="file"
        accept={accept}
        onChange={handleChange}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
      />
      <div className="flex flex-col items-center gap-4">
        <div className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-colors ${
          fileName ? 'bg-primary/20' : 'bg-muted group-hover:bg-primary/10'
        }`}>
          <Icon className={`w-7 h-7 ${fileName ? 'text-primary' : 'text-muted-foreground group-hover:text-primary'}`} />
        </div>
        {fileName ? (
          <>
            <p className="font-semibold text-foreground">{fileName}</p>
            <p className="text-sm text-primary">File loaded successfully</p>
          </>
        ) : (
          <>
            <p className="font-semibold text-foreground">{label || 'Drop your file here'}</p>
            <p className="text-sm text-muted-foreground">{sublabel || 'or click to browse'}</p>
          </>
        )}
      </div>
    </div>
  );
}