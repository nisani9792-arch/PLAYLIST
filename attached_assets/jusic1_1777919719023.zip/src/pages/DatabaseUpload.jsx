import React, { useState, useRef } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Database, Trash2, Upload, FolderOpen } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import PageHeader from '@/components/shared/PageHeader';
import Papa from 'papaparse';
import * as XLSX from 'xlsx';

function mapRow(row) {
  const keys = {};
  Object.keys(row).forEach(k => { keys[k.trim()] = row[k]; });

  const songName = keys['שם'] || keys['שם שיר'] || keys['song_name'] || keys['name'] || keys['title'] || '';
  const artist = keys['אמן ראשי'] || keys['אמן'] || keys['אמנים'] || keys['artist'] || '';
  const genre = keys['זאנרים'] || keys["ז'אנר"] || keys['ז׳אנר'] || keys['genre'] || keys['סוג'] || '';
  const songId = keys['id'] || keys['מזהה'] || '';

  return { song_id: String(songId), song_name: String(songName || ''), artist: String(artist || ''), genre: String(genre || '') };
}

function parseExcel(file, onDone, onError) {
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const wb = XLSX.read(e.target.result, { type: 'array' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const data = XLSX.utils.sheet_to_json(ws, { defval: '' });
      const mapped = data.map(mapRow).filter(r => r.song_name && r.song_name !== 'undefined');
      onDone(mapped);
    } catch (err) {
      onError(err);
    }
  };
  reader.onerror = onError;
  reader.readAsArrayBuffer(file);
}

function parseCSV(file, onDone, onError) {
  Papa.parse(file, {
    header: true,
    skipEmptyLines: true,
    encoding: 'UTF-8',
    complete: (results) => {
      const mapped = results.data.map(mapRow).filter(r => r.song_name && r.song_name !== 'undefined');
      onDone(mapped);
    },
    error: onError,
  });
}

export default function DatabaseUpload() {
  const [parsedSongs, setParsedSongs] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const [isImporting, setIsImporting] = useState(false);
  const fileInputRef = useRef(null);
  const queryClient = useQueryClient();

  const { data: existingSongs = [] } = useQuery({
    queryKey: ['songs'],
    queryFn: () => base44.entities.Song.list(),
  });

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) setSelectedFile(file);
  };

  const handleParse = () => {
    if (!selectedFile) { toast.error('יש לבחור קובץ תחילה'); return; }

    const isExcel = /\.(xlsx|xls)$/i.test(selectedFile.name);
    const onDone = (mapped) => {
      if (mapped.length === 0) { toast.error('לא נמצאו שירים — בדוק את כותרות העמודות'); return; }
      setParsedSongs(mapped);
      toast.success(`הנתונים נטענו בהצלחה! נמצאו ${mapped.length} שירים`);
    };
    const onError = (err) => toast.error('שגיאה בפענוח הקובץ: ' + err.message);

    if (isExcel) parseExcel(selectedFile, onDone, onError);
    else parseCSV(selectedFile, onDone, onError);
  };

  const handleImportToDB = async () => {
    if (parsedSongs.length === 0) return;
    setIsImporting(true);
    const batchSize = 50;
    for (let i = 0; i < parsedSongs.length; i += batchSize) {
      await base44.entities.Song.bulkCreate(parsedSongs.slice(i, i + batchSize));
    }
    queryClient.invalidateQueries({ queryKey: ['songs'] });
    toast.success(`יובאו ${parsedSongs.length} שירים למאגר הנתונים`);
    setParsedSongs([]);
    setSelectedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    setIsImporting(false);
  };

  const handleClearAll = async () => {
    if (!confirm('למחוק את כל השירים מהמאגר?')) return;
    for (const song of existingSongs) await base44.entities.Song.delete(song.id);
    queryClient.invalidateQueries({ queryKey: ['songs'] });
    toast.success('המאגר נוקה');
  };

  return (
    <div>
      <PageHeader icon={Database} title="העלאת מאגר שירים" subtitle="בחר קובץ CSV או Excel עם עמודות שם שיר, אמן ראשי, זאנרים">
        {existingSongs.length > 0 && (
          <Button type="button" variant="outline" onClick={handleClearAll} className="gap-2 text-destructive hover:text-destructive">
            <Trash2 className="w-4 h-4" /> נקה מאגר ({existingSongs.length})
          </Button>
        )}
      </PageHeader>

      <Card className="p-6 mb-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium mb-2">בחר קובץ CSV או Excel</label>
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.xlsx,.xls"
              onChange={handleFileChange}
              className="block w-full text-sm text-muted-foreground file:ml-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-primary/10 file:text-primary hover:file:bg-primary/20 cursor-pointer"
            />
            {selectedFile && (
              <p className="mt-2 text-xs text-muted-foreground flex items-center gap-1">
                <FolderOpen className="w-3.5 h-3.5" />
                {selectedFile.name} — ({(selectedFile.size / 1024).toFixed(1)} KB)
              </p>
            )}
          </div>
          <Button type="button" onClick={handleParse} disabled={!selectedFile} className="gap-2 h-11 px-6 shrink-0">
            <Database className="w-4 h-4" />
            טען מסד נתונים
          </Button>
        </div>
      </Card>

      {parsedSongs.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">תצוגה מקדימה — {parsedSongs.length} שירים</h2>
            <Button type="button" onClick={handleImportToDB} disabled={isImporting} className="gap-2">
              <Upload className="w-4 h-4" />
              {isImporting ? 'מייבא...' : 'שמור למאגר הנתונים'}
            </Button>
          </div>
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/50">
                    <th className="text-right p-4 font-semibold text-muted-foreground">שם שיר / אלבום</th>
                    <th className="text-right p-4 font-semibold text-muted-foreground">אמן ראשי</th>
                    <th className="text-right p-4 font-semibold text-muted-foreground">ז׳אנר / סוג</th>
                  </tr>
                </thead>
                <tbody>
                  {parsedSongs.slice(0, 100).map((song, i) => (
                    <tr key={i} className="border-b border-border last:border-0 hover:bg-accent/30 transition-colors">
                      <td className="p-4 font-medium">{song.song_name}</td>
                      <td className="p-4">{song.artist || '—'}</td>
                      <td className="p-4">
                        <span className="text-xs px-2 py-1 rounded-full bg-accent text-accent-foreground">
                          {song.genre || '—'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {parsedSongs.length > 100 && (
              <div className="p-4 text-center text-sm text-muted-foreground border-t border-border">
                מציג 100 ראשונים מתוך {parsedSongs.length} שירים
              </div>
            )}
          </Card>
        </div>
      )}
    </div>
  );
}