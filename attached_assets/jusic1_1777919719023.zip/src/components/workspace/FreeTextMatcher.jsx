import React, { useState } from 'react';
import { Wand2, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import Fuse from 'fuse.js';

export default function FreeTextMatcher({ songs, playlistSongs, onAddSongs }) {
  const [rawText, setRawText] = useState('');
  const [results, setResults] = useState(null);
  const [isMatching, setIsMatching] = useState(false);

  const handleMatch = () => {
    if (!rawText.trim()) return;
    if (songs.length === 0) {
      toast.error('אין שירים במאגר לחיפוש');
      return;
    }
    setIsMatching(true);
    const lines = rawText.split('\n').map(l => l.trim()).filter(Boolean);
    const fuse = new Fuse(songs, { keys: ['song_name', 'artist'], threshold: 0.45, includeScore: true });

    const matched = [];
    const notFound = [];
    for (const line of lines) {
      const hits = fuse.search(line);
      if (hits.length > 0) matched.push({ query: line, song: hits[0].item });
      else notFound.push(line);
    }
    setResults({ matched, notFound });

    const playlistIds = new Set(playlistSongs.map(s => s.id));
    const toAdd = matched.filter(r => !playlistIds.has(r.song.id)).map(r => r.song);
    const dupes = matched.filter(r => playlistIds.has(r.song.id));

    if (dupes.length > 0) toast.warning(`${dupes.length} שיר/ים כבר בפלייליסט — דולגו`);
    if (notFound.length > 0) toast.warning(`לא נמצאה התאמה עבור ${notFound.length} שורות`);
    if (toAdd.length > 0) {
      onAddSongs(toAdd);
      toast.success(`נוספו ${toAdd.length} שירים לפלייליסט`);
    }
    setIsMatching(false);
  };

  return (
    <Card className="p-5 mt-6 border-dashed">
      <div className="flex items-center gap-2 mb-2">
        <Wand2 className="w-5 h-5 text-primary" />
        <h3 className="font-semibold">התאמת טקסט חופשי</h3>
      </div>
      <p className="text-xs text-muted-foreground mb-3">
        הדבק רשימת שמות שירים (שורה אחת לכל שיר) — המנוע יתאים אוטומטית לשירים המתאימים ביותר
      </p>
      <Textarea
        placeholder={"שוואקי - מה אדיר\nאברהם פריד\nמוצרט סימפוניה...\n"}
        value={rawText}
        onChange={e => setRawText(e.target.value)}
        className="min-h-[110px] text-sm font-mono mb-3"
        dir="auto"
      />

      {results && (
        <div className="mb-3 space-y-1 max-h-36 overflow-y-auto rounded-lg bg-muted/40 p-3">
          {results.matched.map((r, i) => (
            <div key={i} className="flex items-center gap-2 text-xs">
              <CheckCircle className="w-3.5 h-3.5 text-green-500 shrink-0" />
              <span className="text-muted-foreground truncate">"{r.query}"</span>
              <span className="text-foreground font-medium shrink-0">← {r.song.song_name}</span>
            </div>
          ))}
          {results.notFound.map((q, i) => (
            <div key={i} className="flex items-center gap-2 text-xs">
              <AlertCircle className="w-3.5 h-3.5 text-destructive shrink-0" />
              <span className="text-muted-foreground">"{q}"</span>
              <span className="text-destructive shrink-0">— לא נמצא</span>
            </div>
          ))}
        </div>
      )}

      <Button onClick={handleMatch} disabled={isMatching || !rawText.trim()} className="w-full gap-2">
        {isMatching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
        התאם והוסף לפלייליסט
      </Button>
    </Card>
  );
}