import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, ListMusic, Sun, Moon } from 'lucide-react';
import { Button } from '@/components/ui/button';

const navItems = [
  { path: '/', label: 'לוח בקרה', icon: LayoutDashboard },
  { path: '/workspace', label: 'עריכת פלייליסט', icon: ListMusic },
];

export default function Sidebar({ darkMode, onToggleDarkMode }) {
  const location = useLocation();

  return (
    <aside className="w-64 h-screen fixed right-0 top-0 bg-card border-l border-border flex flex-col z-50">
      <div className="p-5 border-b border-border">
        <div className="flex items-center gap-3">
          <img src="https://media.base44.com/images/public/69f78e025a173e01ad5e2b2e/3c9c2c56c_.png" alt="לוגו" className="w-10 h-10 object-contain" />
          <div>
            <div className="text-xs font-semibold text-muted-foreground tracking-widest uppercase">Build Play</div>
            <div className="text-xl font-extrabold tracking-tight text-primary leading-tight">JUSIC</div>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map(({ path, label, icon: Icon }) => {
          const isActive = location.pathname === path;
          return (
            <Link
              key={path}
              to={path}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${
                isActive
                  ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25'
                  : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
              }`}
            >
              <Icon className="w-5 h-5 shrink-0" />
              {label}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border">
        <Button
          variant="ghost"
          onClick={onToggleDarkMode}
          className="w-full justify-start gap-3 text-muted-foreground hover:text-foreground"
        >
          {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          {darkMode ? 'מצב בהיר' : 'מצב כהה'}
        </Button>
      </div>
    </aside>
  );
}