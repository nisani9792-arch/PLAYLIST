import React from 'react';
import { Music, Plus, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function SearchResults({ query, results, isSearching, onAdd }) {
  if (!query.trim()) return null;

  if (isSearching && results.length === 0) {
    return (
      <div className="w-full max-w-3xl mx-auto mt-2 bg-card border border-border rounded-2xl shadow-xl p-6 text-center text-muted-foreground text-sm">
        מחפש...
      </div>
    );
  }

  if (!isSearching && results.length === 0) {
    return (
      <div className="w-full max-w-3xl mx-auto mt-2 bg-card border border-border rounded-2xl shadow-xl p-6 text-center text-muted-foreground text-sm">
        <Search className="w-8 h-8 mx-auto mb-2 opacity-30" />
        לא נמצאו תוצאות עבור "{query}"
      </div>
    );
  }

  return (
    <div className="w-full max-w-3xl mx-auto mt-2 bg-card border border-border rounded-2xl shadow-xl overflow-hidden">
      <div className="max-h-72 overflow-y-auto divide-y divide-border">
        {results.map((hit) => {
          const songName = hit.song_name || hit.name || hit.title || '(ללא שם)';
          const artist = hit.artist || hit.artist_name || '';
          const genre = hit.genre || '';
          const audioUrl = hit.audio_url || '';
          return (
            <div key={hit.id} className="flex items-center gap-3 px-4 py-3 hover:bg-accent/40 transition-colors group">
              <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <Music className="w-4 h-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">{songName}</p>
                <p className="text-xs text-muted-foreground truncate">
                  {artist}{genre ? ` · ${genre}` : ''}
                </p>
                {audioUrl && (
                  <audio src={audioUrl} controls className="w-full h-7 mt-1" preload="none" />
                )}
              </div>
              <Button
                type="button"
                size="sm"
                onClick={() => onAdd(hit)}
                className="shrink-0 gap-1 h-8 text-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                הוסף
              </Button>
            </div>
          );
        })}
      </div>
    </div>
  );
}