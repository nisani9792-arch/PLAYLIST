import React from 'react';
import { Download, Trash2, Save, Plus, Music } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Droppable } from '@hello-pangea/dnd';
import PlaylistSongItem from './PlaylistSongItem';

export default function PlaylistPanel({ playlistName, onNameChange, songs, onRemove, onSave, onExport, onClear, isSaving, hideHeader }) {
  return (
    <div className="flex flex-col gap-3">
      {!hideHeader && (
        <>
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-base flex items-center gap-2">
              <Music className="w-4 h-4 text-primary" />
              הפלייליסט שלי
              <span className="text-xs font-normal text-muted-foreground">({songs.length} שירים)</span>
            </h2>
            <Button type="button" variant="ghost" size="sm" onClick={onClear} className="gap-1 text-muted-foreground hover:text-destructive h-7 text-xs px-2">
              <Trash2 className="w-3.5 h-3.5" />
              נקה
            </Button>
          </div>
          <Input
            placeholder="שם הפלייליסט..."
            value={playlistName}
            onChange={e => onNameChange(e.target.value)}
            dir="rtl"
            className="h-9 text-sm"
          />
        </>
      )}

      <Card className="border-dashed flex-1 min-h-[300px] overflow-hidden">
        <Droppable droppableId="playlist">
          {(provided, snapshot) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className={`min-h-[300px] p-2 transition-colors ${snapshot.isDraggingOver ? 'bg-primary/5' : ''}`}
            >
              {songs.length === 0 && !snapshot.isDraggingOver ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <Plus className="w-8 h-8 mb-2 opacity-30" />
                  <p className="text-sm">חפש שירים למעלה ולחץ הוסף</p>
                </div>
              ) : (
                songs.map((song, index) => (
                  <PlaylistSongItem key={`${song.id}-${index}`} song={song} index={index} onRemove={onRemove} />
                ))
              )}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </Card>

      {!hideHeader && (
        <>
          <Button
            type="button"
            onClick={onExport}
            variant="outline"
            disabled={songs.length === 0}
            className="w-full gap-2 h-10 border-primary text-primary hover:bg-primary/5 font-semibold text-sm"
          >
            <Download className="w-4 h-4" />
            ייצוא לאודו (CSV)
          </Button>
          <Button
            type="button"
            onClick={onSave}
            disabled={isSaving || songs.length === 0}
            className="w-full gap-2 h-10 text-sm"
          >
            <Save className="w-4 h-4" />
            {isSaving ? 'שומר...' : 'שמור פלייליסט'}
          </Button>
        </>
      )}
    </div>
  );
}