import React, { useState, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';

export default function AppLayout() {
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem('jusic-dark-mode') === 'true';
  });

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    localStorage.setItem('jusic-dark-mode', darkMode);
  }, [darkMode]);

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <Sidebar darkMode={darkMode} onToggleDarkMode={() => setDarkMode(!darkMode)} />
      <main className="mr-64 p-8">
        <Outlet />
      </main>
    </div>
  );
}