import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { LayoutDashboard, Music, ListMusic, Users, Database } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import PageHeader from '@/components/shared/PageHeader';
import StatCard from '@/components/shared/StatCard';

export default function Dashboard() {
  const { data: songs = [] } = useQuery({
    queryKey: ['songs'],
    queryFn: () => base44.entities.Song.list(),
  });

  const { data: playlists = [] } = useQuery({
    queryKey: ['playlists'],
    queryFn: () => base44.entities.Playlist.list(),
  });

  const uniqueArtists = new Set(songs.map(s => s.artist).filter(Boolean)).size;
  const uniqueGenres = new Set(songs.map(s => s.genre).filter(Boolean)).size;

  const quickActions = [
    { label: 'עריכת פלייליסט', path: '/workspace', icon: ListMusic, desc: 'חפש שירים במאגר Meilisearch ובנה פלייליסטים' },
  ];

  return (
    <div>
      <PageHeader
        icon={LayoutDashboard}
        title="לוח בקרה"
        subtitle="ברוכים הבאים ל-BUILD PLAY JUSIC — מרכז ניהול הפלייליסטים שלך"
      />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard title="סה״כ שירים" value={songs.length} icon={Music} color="primary" />
        <StatCard title="פלייליסטים" value={playlists.length} icon={ListMusic} color="secondary" />
        <StatCard title="אמנים" value={uniqueArtists} icon={Users} color="primary" />
        <StatCard title="ז׳אנרים" value={uniqueGenres} icon={Database} color="secondary" />
      </div>

      <h2 className="text-lg font-semibold mb-4">פעולות מהירות</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {quickActions.map(({ label, path, icon: Icon, desc }) => (
          <Link key={path} to={path}>
            <Card className="p-6 hover:shadow-lg hover:border-primary/30 transition-all duration-300 cursor-pointer group">
              <div className="flex items-center gap-4 mb-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold">{label}</h3>
              </div>
              <p className="text-sm text-muted-foreground">{desc}</p>
            </Card>
          </Link>
        ))}
      </div>

      {songs.length > 0 && (
        <div className="mt-8">
          <h2 className="text-lg font-semibold mb-4">שירים אחרונים</h2>
          <Card className="overflow-hidden">
            <div className="divide-y divide-border">
              {songs.slice(0, 5).map((song) => (
                <div key={song.id} className="flex items-center gap-4 px-6 py-4 hover:bg-accent/50 transition-colors">
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Music className="w-4 h-4 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{song.song_name}</p>
                    <p className="text-sm text-muted-foreground truncate">{song.artist}</p>
                  </div>
                  <span className="text-xs px-3 py-1 rounded-full bg-accent text-accent-foreground font-medium">
                    {song.genre || 'לא ידוע'}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}