import React, { useState } from 'react';
import { Sparkles, Loader2, CheckCircle, AlertCircle, CheckCheck } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

function normalizeHit(hit) {
  return {
    id: hit.id,
    song_name: hit.song_name || hit.name || hit.title || '',
    artist: hit.artist || hit.artist_name || '',
    genre: hit.genre || '',
    album: hit.album || '',
    audio_url: hit.audio_url || '',
  };
}

export default function AiPlaylistPanel({ msConfig, onApproveAll }) {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [staging, setStaging] = useState([]);

  const { msUrl, msApiKey, msIndex } = msConfig;

  const searchOne = async (q) => {
    const token = msApiKey.startsWith('Bearer ') ? msApiKey : `Bearer ${msApiKey}`;
    const res = await fetch(`${msUrl}/indexes/${msIndex}/search`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': token,
      },
      body: JSON.stringify({ q, limit: 1, offset: 0, filter: [] }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.hits?.[0] ? normalizeHit(data.hits[0]) : null;
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) { toast.error('הכנס בקשה'); return; }
    setIsGenerating(true);
    setStaging([]);

    // Step 1: Ask Gemini for song list
    let lines = [];
    try {
      const res = await base44.functions.invoke('geminiPlaylist', { prompt });
      lines = res.data?.lines || [];
      if (lines.length === 0) { toast.error('Gemini לא החזיר שירים'); setIsGenerating(false); return; }
    } catch (err) {
      toast.error('שגיאת Gemini: ' + err.message);
      setIsGenerating(false);
      return;
    }

    // Step 2: Initialize staging
    setStaging(lines.map(q => ({ query: q, hit: null, loading: true })));

    // Step 3: Batch search in Meilisearch
    const BATCH = 5;
    const results = new Array(lines.length).fill(null);

    for (let i = 0; i < lines.length; i += BATCH) {
      const batch = lines.slice(i, i + BATCH);
      const batchHits = await Promise.all(batch.map(q => searchOne(q).catch(() => null)));
      batchHits.forEach((hit, j) => { results[i + j] = hit; });
      setStaging(prev => prev.map((s, idx) => {
        if (idx >= i && idx < i + BATCH) return { ...s, hit: results[idx], loading: false };
        return s;
      }));
    }

    setIsGenerating(false);
    const found = results.filter(Boolean).length;
    toast.success(`Gemini הציע ${lines.length} שירים — נמצאו ${found} במאגר`);
  };

  const handleApproveAll = () => {
    const matched = staging.filter(s => s.hit).map(s => s.hit);
    if (matched.length === 0) { toast.error('אין התאמות לאישור'); return; }
    onApproveAll(matched);
    setStaging([]);
    setPrompt('');
    toast.success(`${matched.length} שירים נוספו לפלייליסט`);
  };

  const foundCount = staging.filter(s => s.hit).length;

  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-3">
        <Sparkles className="w-4 h-4 text-primary" />
        <h3 className="font-bold text-sm">מחולל פלייליסט AI</h3>
      </div>

      <div className="flex gap-2 mb-3">
        <Input
          placeholder='לדוגמה: "צור פלייליסט למוצאי שבת"'
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleGenerate()}
          dir="rtl"
          className="h-9 text-sm flex-1"
        />
        <Button type="button" onClick={handleGenerate} disabled={isGenerating || !prompt.trim()} className="gap-1.5 h-9 text-sm shrink-0">
          {isGenerating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
          {isGenerating ? 'יוצר...' : 'צור'}
        </Button>
      </div>

      {staging.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs text-muted-foreground">אזור קידום — {foundCount}/{staging.length} נמצאו</p>
            <Button type="button" size="sm" onClick={handleApproveAll} disabled={foundCount === 0} className="gap-1 h-7 text-xs">
              <CheckCheck className="w-3 h-3" />
              אשר הכל ({foundCount})
            </Button>
          </div>
          <div className="rounded-lg border border-border overflow-hidden max-h-48 overflow-y-auto">
            <table className="w-full text-xs">
              <tbody className="divide-y divide-border">
                {staging.map((row, i) => (
                  <tr key={i} className={row.hit ? 'hover:bg-accent/30' : 'opacity-50'}>
                    <td className="p-2 pr-3 w-5">
                      {row.loading
                        ? <Loader2 className="w-3 h-3 animate-spin text-muted-foreground" />
                        : row.hit
                          ? <CheckCircle className="w-3 h-3 text-green-500" />
                          : <AlertCircle className="w-3 h-3 text-destructive" />}
                    </td>
                    <td className="p-2 text-muted-foreground truncate max-w-[100px]">{row.query}</td>
                    <td className="p-2 font-medium truncate max-w-[120px]">{row.hit?.song_name || '—'}</td>
                    <td className="p-2 text-muted-foreground truncate max-w-[80px]">{row.hit?.artist || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </Card>
  );
}