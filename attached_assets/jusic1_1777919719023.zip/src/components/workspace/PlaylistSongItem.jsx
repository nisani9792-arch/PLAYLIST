import React from 'react';
import { Draggable } from '@hello-pangea/dnd';
import { GripVertical, Music, X } from 'lucide-react';

export default function PlaylistSongItem({ song, index, onRemove }) {
  return (
    <Draggable draggableId={`playlist-${song.id}-${index}`} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          className={`flex items-center gap-3 px-4 py-3 rounded-xl mb-2 transition-all duration-200 ${
            snapshot.isDragging
              ? 'bg-secondary/20 shadow-lg shadow-secondary/10 ring-2 ring-secondary/30'
              : 'bg-card hover:bg-accent/50 border border-border'
          }`}
        >
          <span className="text-xs font-bold text-muted-foreground w-6 text-center shrink-0">
            {index + 1}
          </span>
          <GripVertical className="w-4 h-4 text-muted-foreground/50 shrink-0" />
          <div className="w-8 h-8 rounded-lg bg-secondary/10 flex items-center justify-center shrink-0">
            <Music className="w-4 h-4 text-secondary" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{song.song_name}</p>
            <p className="text-xs text-muted-foreground truncate">{song.artist}</p>
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); onRemove(index); }}
            className="w-7 h-7 rounded-lg hover:bg-destructive/10 flex items-center justify-center transition-colors shrink-0"
          >
            <X className="w-3.5 h-3.5 text-muted-foreground hover:text-destructive" />
          </button>
        </div>
      )}
    </Draggable>
  );
}