import React, { useState } from 'react';
import { Sparkles, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const GEMINI_API_KEY = 'YOUR_GEMINI_API_KEY';

export default function AiAnalysisModal({ playlistSongs, playlistName, onClose }) {
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleAnalyze = async () => {
    if (playlistSongs.length === 0) {
      toast.error('הפלייליסט ריק — הוסף שירים תחילה');
      return;
    }
    setIsLoading(true);
    const songList = playlistSongs.map((s, i) => `${i + 1}. ${s.song_name}${s.artist ? ` - ${s.artist}` : ''}`).join('\n');
    const prompt = `נתח את רשימת השירים הזו. סדר אותם לפי נושאים, זיהוי אווירה, והצע זרימת השמעה (Flow) חכמה.\n\nפלייליסט: ${playlistName || 'ללא שם'}\n\n${songList}`;

    try {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
      });
      const data = await res.json();
      if (data.candidates?.[0]?.content?.parts?.[0]?.text) {
        setResult(data.candidates[0].content.parts[0].text);
      } else {
        toast.error('לא התקבלה תשובה מה-AI — בדוק את ה-API Key');
      }
    } catch (err) {
      toast.error('שגיאת תקשורת עם Gemini: ' + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div
        className="bg-card rounded-2xl shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col border border-border"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-bold">ניתוח AI</h2>
              <p className="text-xs text-muted-foreground">מופעל על ידי Google Gemini</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Song list preview */}
        <div className="px-6 pt-4">
          <p className="text-sm text-muted-foreground mb-2">
            {playlistSongs.length} שירים בפלייליסט — Gemini ינתח את האווירה, הנושאים ויציע זרימה חכמה
          </p>
        </div>

        {/* Result area */}
        <div className="flex-1 overflow-y-auto px-6 py-3">
          {result ? (
            <div className="bg-muted/50 rounded-xl p-5 text-sm leading-relaxed whitespace-pre-wrap border border-border">
              {result}
            </div>
          ) : (
            <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>מנתח את הפלייליסט...</span>
                </div>
              ) : (
                <span>לחץ על הכפתור למטה להתחלת הניתוח</span>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-border">
          <Button onClick={handleAnalyze} disabled={isLoading} className="w-full gap-2 h-11">
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            {isLoading ? 'מנתח...' : 'נתח עם AI'}
          </Button>
          {GEMINI_API_KEY === 'YOUR_GEMINI_API_KEY' && (
            <p className="text-xs text-destructive text-center mt-2">⚠️ יש להחליף את YOUR_GEMINI_API_KEY במפתח אמיתי</p>
          )}
        </div>
      </div>
    </div>
  );
}