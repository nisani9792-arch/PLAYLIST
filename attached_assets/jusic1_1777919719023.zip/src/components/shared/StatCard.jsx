import React from 'react';
import { Card } from '@/components/ui/card';

export default function StatCard({ title, value, icon: Icon, color = 'primary' }) {
  return (
    <Card className="p-6 relative overflow-hidden group hover:shadow-lg transition-shadow duration-300">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-3xl font-bold mt-2 tracking-tight">{value}</p>
        </div>
        <div className={`w-11 h-11 rounded-xl bg-${color}/10 flex items-center justify-center`}>
          <Icon className={`w-5 h-5 text-${color}`} />
        </div>
      </div>
      <div className={`absolute bottom-0 left-0 right-0 h-1 bg-${color}/20 group-hover:bg-${color}/40 transition-colors`} />
    </Card>
  );
}