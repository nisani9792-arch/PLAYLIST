import React, { useState } from 'react';
import { Wand2, Loader2, CheckCircle, AlertCircle, CheckCheck } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

function normalizeHit(hit) {
  return {
    id: hit.id,
    song_name: hit.song_name || hit.name || hit.title || '',
    artist: hit.artist || hit.artist_name || '',
    genre: hit.genre || '',
    album: hit.album || '',
    audio_url: hit.audio_url || '',
  };
}

export default function BulkImport({ msConfig, onApproveAll }) {
  const [rawText, setRawText] = useState('');
  const [staging, setStaging] = useState([]);
  const [isMatching, setIsMatching] = useState(false);

  const { msUrl, msApiKey, msIndex } = msConfig;

  const searchOne = async (q) => {
    const token = msApiKey.startsWith('Bearer ') ? msApiKey : `Bearer ${msApiKey}`;
    const res = await fetch(`${msUrl}/indexes/${msIndex}/search`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': token,
      },
      body: JSON.stringify({ q, limit: 1, offset: 0, filter: [] }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.hits?.[0] ? normalizeHit(data.hits[0]) : null;
  };

  const handleMatch = async () => {
    const lines = rawText.split('\n').map(l => l.trim()).filter(Boolean);
    if (lines.length === 0) { toast.error('אנא הדבק שמות שירים'); return; }
    setStaging(lines.map(q => ({ query: q, hit: null, loading: true })));
    setIsMatching(true);

    const BATCH = 5;
    const results = new Array(lines.length).fill(null);
    for (let i = 0; i < lines.length; i += BATCH) {
      const batch = lines.slice(i, i + BATCH);
      const batchHits = await Promise.all(batch.map(q => searchOne(q).catch(() => null)));
      batchHits.forEach((hit, j) => { results[i + j] = hit; });
      setStaging(prev => prev.map((s, idx) => {
        if (idx >= i && idx < i + BATCH) return { ...s, hit: results[idx], loading: false };
        return s;
      }));
    }

    setIsMatching(false);
    const found = results.filter(Boolean).length;
    toast.success(`נמצאו ${found} התאמות מתוך ${lines.length}`);
  };

  const handleApproveAll = () => {
    const matched = staging.filter(s => s.hit).map(s => s.hit);
    if (matched.length === 0) { toast.error('אין התאמות לאישור'); return; }
    onApproveAll(matched);
    setStaging([]);
    setRawText('');
    toast.success(`${matched.length} שירים נוספו לפלייליסט`);
  };

  const foundCount = staging.filter(s => s.hit).length;

  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-2">
        <Wand2 className="w-4 h-4 text-primary" />
        <h3 className="font-bold text-sm">הוספה מהירה (טקסט חופשי)</h3>
      </div>
      <p className="text-xs text-muted-foreground mb-2">הדבק רשימת שמות שירים — שורה אחת לכל שיר</p>

      <Textarea
        placeholder={"שוואקי - מה אדיר\nאברהם פריד\nלחיות את החיים..."}
        value={rawText}
        onChange={e => setRawText(e.target.value)}
        className="min-h-[80px] text-xs font-mono mb-2"
        dir="auto"
      />

      <Button type="button" onClick={handleMatch} disabled={isMatching || !rawText.trim()} className="w-full gap-2 h-9 text-sm mb-3">
        {isMatching ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Wand2 className="w-3.5 h-3.5" />}
        מצא התאמות
      </Button>

      {staging.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <p className="text-xs text-muted-foreground">טבלת קידום — {foundCount}/{staging.length} נמצאו</p>
            <Button type="button" size="sm" onClick={handleApproveAll} disabled={foundCount === 0} className="gap-1 h-7 text-xs">
              <CheckCheck className="w-3 h-3" />
              אשר הכל ({foundCount})
            </Button>
          </div>
          <div className="rounded-lg border border-border overflow-hidden max-h-48 overflow-y-auto">
            <table className="w-full text-xs">
              <tbody className="divide-y divide-border">
                {staging.map((row, i) => (
                  <tr key={i} className={row.hit ? 'hover:bg-accent/30' : 'opacity-50'}>
                    <td className="p-2 pr-3 w-5">
                      {row.loading
                        ? <Loader2 className="w-3 h-3 animate-spin text-muted-foreground" />
                        : row.hit
                          ? <CheckCircle className="w-3 h-3 text-green-500" />
                          : <AlertCircle className="w-3 h-3 text-destructive" />}
                    </td>
                    <td className="p-2 text-muted-foreground truncate max-w-[100px]">{row.query}</td>
                    <td className="p-2 font-medium truncate max-w-[120px]">{row.hit?.song_name || '—'}</td>
                    <td className="p-2 text-muted-foreground truncate">{row.hit?.artist || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </Card>
  );
}