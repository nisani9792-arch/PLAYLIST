import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { prompt } = await req.json();
    if (!prompt) return Response.json({ error: 'Missing prompt' }, { status: 400 });

    const apiKey = Deno.env.get('GEMINI_API_KEY');
    const fullPrompt = `אתה עוזר מוזיקלי. המשתמש ביקש: "${prompt}".
החזר רשימה של שמות שירים בלבד — שורה אחת לכל שיר, ללא מספרים, ללא סימנים, רק שם השיר ואמן אם רלוונטי.
החזר רק את הרשימה, ללא טקסט נוסף.`;

    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents: [{ parts: [{ text: fullPrompt }] }] }),
      }
    );

    const data = await res.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

    return Response.json({ lines });
  } catch (err) {
    return Response.json({ error: err.message }, { status: 500 });
  }
});