import React from 'react';
import { Draggable } from '@hello-pangea/dnd';
import { GripVertical, Music } from 'lucide-react';

export default function SongListItem({ song, index, listId }) {
  return (
    <Draggable draggableId={`${listId}-${song.id}`} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          className={`flex items-center gap-3 px-4 py-3 rounded-xl mb-2 transition-all duration-200 ${
            snapshot.isDragging
              ? 'bg-primary/10 shadow-lg shadow-primary/10 ring-2 ring-primary/30'
              : 'bg-card hover:bg-accent/50 border border-border'
          }`}
        >
          <GripVertical className="w-4 h-4 text-muted-foreground/50 shrink-0" />
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
            <Music className="w-4 h-4 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{song.song_name}</p>
            <p className="text-xs text-muted-foreground truncate">{song.artist}</p>
          </div>
          {song.genre && (
            <span className="text-xs px-2 py-0.5 rounded-full bg-accent text-accent-foreground shrink-0 hidden sm:inline">
              {song.genre}
            </span>
          )}
        </div>
      )}
    </Draggable>
  );
}