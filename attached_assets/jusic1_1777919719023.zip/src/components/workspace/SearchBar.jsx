import React, { useRef } from 'react';
import { Search, Loader2, Settings } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function SearchBar({ query, onChange, isSearching, onOpenSettings }) {
  return (
    <div className="relative w-full max-w-3xl mx-auto">
      <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" />
      {isSearching
        ? <Loader2 className="absolute left-12 top-1/2 -translate-y-1/2 w-4 h-4 text-primary animate-spin" />
        : null}
      <Input
        placeholder="חיפוש חי — שם שיר, אמן, ז׳אנר..."
        value={query}
        onChange={onChange}
        className="pr-12 pl-24 h-14 text-base rounded-2xl border-2 border-primary/30 focus:border-primary shadow-lg shadow-primary/10"
        dir="rtl"
        autoFocus
      />
      <Button
        type="button"
        variant="ghost"
        size="sm"
        onClick={onOpenSettings}
        className="absolute left-2 top-1/2 -translate-y-1/2 h-9 gap-1.5 text-muted-foreground hover:text-foreground text-xs"
      >
        <Settings className="w-3.5 h-3.5" />
        הגדרות
      </Button>
    </div>
  );
}