import React, { useState, useRef, useCallback } from 'react';
import { Search, Settings, Loader2, Music, Plus } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import BulkImport from './BulkImport';

export default function MeilisearchPane({ msConfig, onMsConfigChange, onAddToPlaylist }) {
  const { msUrl, msApiKey, msIndex } = msConfig;
  const [showSettings, setShowSettings] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const debounceTimer = useRef(null);

  const doSearch = useCallback(async (q) => {
    if (!q.trim()) { setResults([]); return; }
    setIsSearching(true);
    try {
      const res = await fetch(`${msUrl}/indexes/${msIndex}/search`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': msApiKey.startsWith('Bearer ') ? msApiKey : `Bearer ${msApiKey}`,
        },
        body: JSON.stringify({ q, limit: 20 }),
      });
      if (!res.ok) throw new Error(`שגיאת שרת: ${res.status}`);
      const data = await res.json();
      setResults(data.hits || []);
    } catch (err) {
      toast.error('שגיאת חיפוש: ' + err.message);
      setResults([]);
    } finally {
      setIsSearching(false);
    }
  }, [msUrl, msApiKey, msIndex]);

  const handleQueryChange = (e) => {
    const val = e.target.value;
    setQuery(val);
    clearTimeout(debounceTimer.current);
    debounceTimer.current = setTimeout(() => doSearch(val), 350);
  };

  const handleAdd = (hit) => {
    onAddToPlaylist({
      id: hit.id,
      song_name: hit.song_name || hit.name || hit.title || '',
      artist: hit.artist || hit.artist_name || '',
      genre: hit.genre || '',
      album: hit.album || '',
      audio_url: hit.audio_url || '',
    });
  };

  return (
    <div>
      <div className="flex items-center gap-3 mb-4">
        <h2 className="text-lg font-semibold flex-1">חיפוש שירים</h2>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          onClick={() => setShowSettings(!showSettings)}
          className="text-muted-foreground hover:text-foreground"
          title="הגדרות Meilisearch"
        >
          <Settings className="w-4 h-4" />
        </Button>
      </div>

      {showSettings && (
        <Card className="p-4 mb-4 space-y-3 bg-muted/30 border-dashed">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">הגדרות Meilisearch</p>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">כתובת שרת</label>
            <Input value={msUrl} onChange={e => onMsConfigChange('msUrl', e.target.value)} placeholder="http://..." dir="ltr" className="font-mono text-sm" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">API Key (Bearer token)</label>
            <Input value={msApiKey} onChange={e => onMsConfigChange('msApiKey', e.target.value)} placeholder="Bearer ..." dir="ltr" className="font-mono text-sm" type="password" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">שם האינדקס</label>
            <Input value={msIndex} onChange={e => onMsConfigChange('msIndex', e.target.value)} placeholder="music" dir="ltr" className="font-mono text-sm" />
          </div>
        </Card>
      )}

      <div className="relative mb-4">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        {isSearching && <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-primary animate-spin" />}
        <Input
          placeholder="חיפוש חי — שם שיר, אמן..."
          value={query}
          onChange={handleQueryChange}
          className="pr-10 pl-10"
          dir="rtl"
        />
      </div>

      <Card className="overflow-hidden">
        {!query.trim() ? (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <Search className="w-10 h-10 mb-3 opacity-30" />
            <p className="font-medium">הקלד כדי לחפש</p>
            <p className="text-xs mt-1">מחובר ל-Meilisearch</p>
          </div>
        ) : isSearching && results.length === 0 ? (
          <div className="flex items-center justify-center py-16 text-muted-foreground">
            <Loader2 className="w-5 h-5 animate-spin ml-2" /> מחפש...
          </div>
        ) : results.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <Music className="w-10 h-10 mb-3 opacity-30" />
            <p className="font-medium">לא נמצאו תוצאות</p>
          </div>
        ) : (
          <div className="divide-y divide-border max-h-[480px] overflow-y-auto">
            {results.map((hit) => {
              const songName = hit.song_name || hit.name || hit.title || '(ללא שם)';
              const artist = hit.artist || hit.artist_name || '';
              const audioUrl = hit.audio_url || '';
              return (
                <div key={hit.id} className="flex items-center gap-3 px-4 py-3 hover:bg-accent/40 transition-colors group">
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Music className="w-4 h-4 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">{songName}</p>
                    {artist && <p className="text-xs text-muted-foreground truncate">{artist}</p>}
                    {audioUrl && (
                      <audio src={audioUrl} controls className="w-full h-7 mt-1.5" style={{ accentColor: 'hsl(var(--primary))' }} preload="none" />
                    )}
                  </div>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    onClick={() => handleAdd(hit)}
                    className="shrink-0 gap-1 h-8 text-xs border-primary/40 text-primary hover:bg-primary hover:text-primary-foreground"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    הוסף
                  </Button>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      <BulkImport msConfig={msConfig} onApproveAll={(songs) => songs.forEach(s => onAddToPlaylist(s))} />
    </div>
  );
}