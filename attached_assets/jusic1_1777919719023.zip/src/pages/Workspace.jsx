import React, { useState, useCallback, useEffect, useRef } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Music, Download, Save, Trash2, Sparkles, Wand2, ChevronDown, ChevronUp, Settings } from 'lucide-react';
import { toast } from 'sonner';
import { DragDropContext } from '@hello-pangea/dnd';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

import SearchBar from '@/components/workspace/SearchBar';
import SearchResults from '@/components/workspace/SearchResults';
import MsSettingsPanel from '@/components/workspace/MsSettingsPanel';
import PlaylistPanel from '@/components/workspace/PlaylistPanel';
import AiPlaylistPanel from '@/components/workspace/AiPlaylistPanel';
import BulkImport from '@/components/workspace/BulkImport';

const DRAFT_KEY = 'jusic_playlist_draft';

const MS_URL = 'http://164.92.213.53';
const MS_API_KEY = 'e9255b27a8ef254eb0d24828f63b6020e0178d64edc9ab5a529609d215acdc6e';
const MS_INDEX = 'music';

const DEFAULT_MS_CONFIG = {
  msUrl: MS_URL,
  msApiKey: MS_API_KEY,
  msIndex: MS_INDEX,
};

function exportToOdooCSV(playlistName, songs) {
  const BOM = '\uFEFF';
  const headers = ['שם הפלייליסט', 'אמן מבצע', 'שם השיר', 'אלבום'];
  const rows = songs.map(s => [
    playlistName,
    s.artist || '',
    s.song_name || '',
    s.album || '',
  ]);
  const escape = (v) => `"${String(v).replace(/"/g, '""')}"`;
  const csv = BOM + [headers, ...rows].map(r => r.map(escape).join(',')).join('\r\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${playlistName || 'playlist'}_odoo.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function Workspace() {
  const [msConfig, setMsConfig] = useState(DEFAULT_MS_CONFIG);
  const [showSettings, setShowSettings] = useState(false);
  const [showAi, setShowAi] = useState(false);
  const [showBulk, setShowBulk] = useState(false);

  // Search state
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const debounceTimer = useRef(null);

  // Playlist state — restored from localStorage
  const [playlistName, setPlaylistName] = useState(() => {
    try { return JSON.parse(localStorage.getItem(DRAFT_KEY))?.name || ''; } catch { return ''; }
  });
  const [playlistSongs, setPlaylistSongs] = useState(() => {
    try { return JSON.parse(localStorage.getItem(DRAFT_KEY))?.songs || []; } catch { return []; }
  });

  const queryClient = useQueryClient();

  // Auto-save draft
  useEffect(() => {
    localStorage.setItem(DRAFT_KEY, JSON.stringify({ name: playlistName, songs: playlistSongs }));
  }, [playlistSongs, playlistName]);

  const handleMsConfigChange = (key, value) => setMsConfig(prev => ({ ...prev, [key]: value }));

  // Fixed search — matches exact cURL format, filter:[] to get songs (not playlists)
  const doSearch = useCallback(async (q) => {
    if (!q.trim()) { setResults([]); return; }
    setIsSearching(true);
    try {
      const { msUrl, msApiKey, msIndex } = msConfig;
      const token = msApiKey.startsWith('Bearer ') ? msApiKey : `Bearer ${msApiKey}`;
      const res = await fetch(`${msUrl}/indexes/${msIndex}/search`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': token,
        },
        body: JSON.stringify({ q, limit: 20, offset: 0, filter: [] }),
      });
      if (!res.ok) throw new Error(`שגיאת שרת: ${res.status}`);
      const data = await res.json();
      setResults(data.hits || []);
    } catch (err) {
      toast.error('שגיאת חיפוש: ' + err.message);
      setResults([]);
    } finally {
      setIsSearching(false);
    }
  }, [msConfig]);

  const handleQueryChange = (e) => {
    const val = e.target.value;
    setQuery(val);
    if (!val.trim()) { setResults([]); return; }
    clearTimeout(debounceTimer.current);
    debounceTimer.current = setTimeout(() => doSearch(val), 350);
  };

  // Playlist actions
  const addToPlaylist = useCallback((hit) => {
    const song = {
      id: hit.id,
      song_name: hit.song_name || hit.name || hit.title || '',
      artist: hit.artist || hit.artist_name || '',
      genre: hit.genre || '',
      album: hit.album || '',
      audio_url: hit.audio_url || '',
    };
    setPlaylistSongs(prev => {
      if (prev.some(s => s.id === song.id)) {
        toast.warning(`"${song.song_name}" כבר בפלייליסט`);
        return prev;
      }
      toast.success(`"${song.song_name}" נוסף`);
      return [...prev, song];
    });
  }, []);

  const handleApproveAll = useCallback((songs) => {
    setPlaylistSongs(prev => {
      const existingIds = new Set(prev.map(s => s.id));
      const newSongs = songs.filter(s => !existingIds.has(s.id));
      return [...prev, ...newSongs];
    });
  }, []);

  const handleDragEnd = ({ source, destination }) => {
    if (!destination || source.droppableId !== 'playlist' || destination.droppableId !== 'playlist') return;
    setPlaylistSongs(prev => {
      const arr = [...prev];
      const [moved] = arr.splice(source.index, 1);
      arr.splice(destination.index, 0, moved);
      return arr;
    });
  };

  const handleRemove = (index) => setPlaylistSongs(prev => prev.filter((_, i) => i !== index));

  const handleClear = () => {
    setPlaylistSongs([]);
    setPlaylistName('');
    localStorage.removeItem(DRAFT_KEY);
    toast.success('הפלייליסט נוקה');
  };

  const saveMutation = useMutation({
    mutationFn: (data) => base44.entities.Playlist.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['playlists'] });
      toast.success('הפלייליסט נשמר!');
      handleClear();
    },
  });

  const handleSave = () => {
    if (!playlistName.trim()) { toast.error('יש להזין שם לפלייליסט'); return; }
    saveMutation.mutate({
      name: playlistName,
      songs: playlistSongs.map(s => ({ song_id: s.id, song_name: s.song_name, artist: s.artist, genre: s.genre })),
    });
  };

  const handleExport = () => {
    if (!playlistName.trim()) { toast.error('יש להזין שם לפלייליסט'); return; }
    if (playlistSongs.length === 0) { toast.error('הפלייליסט ריק'); return; }
    exportToOdooCSV(playlistName, playlistSongs);
    toast.success('קובץ CSV יוצא בהצלחה!');
  };

  return (
    <div dir="rtl" className="flex flex-col h-full">

      {/* ── TOP: Brand + Search ───────────────────────────────────────── */}
      <div className="flex items-center gap-4 mb-4">
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
            <Music className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-lg font-bold leading-tight">Smart Playlist Builder</h1>
            <p className="text-xs text-muted-foreground">Play Jusic</p>
          </div>
        </div>

        <div className="flex-1">
          <SearchBar
            query={query}
            onChange={handleQueryChange}
            isSearching={isSearching}
            onOpenSettings={() => setShowSettings(s => !s)}
          />
        </div>

        <img
          src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Odoo_logo.svg/200px-Odoo_logo.svg.png"
          alt="Odoo"
          className="h-7 opacity-60 object-contain shrink-0"
        />
      </div>

      {/* Settings panel */}
      {showSettings && (
        <div className="mb-3">
          <MsSettingsPanel
            config={msConfig}
            onChange={handleMsConfigChange}
            onClose={() => setShowSettings(false)}
          />
        </div>
      )}

      {/* Search results dropdown */}
      {(query || results.length > 0 || isSearching) && (
        <div className="mb-3">
          <SearchResults
            query={query}
            results={results}
            isSearching={isSearching}
            onAdd={addToPlaylist}
          />
        </div>
      )}

      {/* ── STICKY ACTION BAR ─────────────────────────────────────────── */}
      <div className="flex items-center gap-2 bg-card border border-border rounded-xl px-4 py-3 mb-4 shadow-sm">
        <Input
          placeholder="שם הפלייליסט..."
          value={playlistName}
          onChange={e => setPlaylistName(e.target.value)}
          className="h-9 text-sm max-w-xs"
          dir="rtl"
        />
        <span className="text-xs text-muted-foreground mx-1">{playlistSongs.length} שירים</span>
        <div className="flex-1" />
        <Button variant="outline" size="sm" onClick={handleClear} disabled={playlistSongs.length === 0} className="gap-1.5 h-8 text-xs text-destructive hover:text-destructive">
          <Trash2 className="w-3.5 h-3.5" />
          נקה
        </Button>
        <Button variant="outline" size="sm" onClick={handleExport} disabled={playlistSongs.length === 0} className="gap-1.5 h-8 text-xs">
          <Download className="w-3.5 h-3.5" />
          ייצא CSV לאודו
        </Button>
        <Button size="sm" onClick={handleSave} disabled={saveMutation.isPending || playlistSongs.length === 0} className="gap-1.5 h-8 text-xs">
          <Save className="w-3.5 h-3.5" />
          {saveMutation.isPending ? 'שומר...' : 'שמור'}
        </Button>
      </div>

      {/* ── MAIN: Playlist Table (center focus) ───────────────────────── */}
      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="flex-1 min-h-0">
          <PlaylistPanel
            playlistName={playlistName}
            onNameChange={setPlaylistName}
            songs={playlistSongs}
            onRemove={handleRemove}
            onSave={handleSave}
            onExport={handleExport}
            onClear={handleClear}
            isSaving={saveMutation.isPending}
            hideHeader
          />
        </div>
      </DragDropContext>

      {/* ── COLLAPSIBLE TOOLS ─────────────────────────────────────────── */}
      <div className="mt-4 flex flex-col gap-2">

        {/* AI Generator */}
        <div className="border border-border rounded-xl overflow-hidden">
          <button
            onClick={() => setShowAi(s => !s)}
            className="w-full flex items-center justify-between px-4 py-2.5 bg-card hover:bg-accent/40 transition-colors text-sm font-semibold"
          >
            <span className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" />
              מחולל פלייליסט AI
            </span>
            {showAi ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
          </button>
          {showAi && (
            <div className="border-t border-border bg-background p-4">
              <AiPlaylistPanel msConfig={msConfig} onApproveAll={handleApproveAll} />
            </div>
          )}
        </div>

        {/* Bulk Text Import */}
        <div className="border border-border rounded-xl overflow-hidden">
          <button
            onClick={() => setShowBulk(s => !s)}
            className="w-full flex items-center justify-between px-4 py-2.5 bg-card hover:bg-accent/40 transition-colors text-sm font-semibold"
          >
            <span className="flex items-center gap-2">
              <Wand2 className="w-4 h-4 text-primary" />
              הוספה מהירה — טקסט חופשי
            </span>
            {showBulk ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
          </button>
          {showBulk && (
            <div className="border-t border-border bg-background p-4">
              <BulkImport msConfig={msConfig} onApproveAll={handleApproveAll} />
            </div>
          )}
        </div>

      </div>
    </div>
  );
}