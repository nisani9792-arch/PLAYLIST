import React, { useState } from 'react';
import { FileText, Copy, Loader2 } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import PageHeader from '@/components/shared/PageHeader';
import FileDropZone from '@/components/shared/FileDropZone';
import { base44 } from '@/api/base44Client';

export default function PdfImport() {
  const [rawText, setRawText] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handlePdf = async (file) => {
    setIsLoading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const result = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url,
        json_schema: {
          type: 'object',
          properties: {
            extracted_text: {
              type: 'string',
              description: 'All the text content from the PDF, preserving paragraph structure'
            }
          }
        }
      });
      if (result.status === 'success' && result.output) {
        setRawText(result.output.extracted_text || JSON.stringify(result.output, null, 2));
        toast.success('הטקסט חולץ בהצלחה מה-PDF');
      } else {
        toast.error('שגיאה בחילוץ הטקסט: ' + (result.details || 'שגיאה לא ידועה'));
      }
    } catch (err) {
      toast.error('שגיאה בעיבוד ה-PDF: ' + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(rawText);
    toast.success('הטקסט הועתק ללוח');
  };

  return (
    <div>
      <PageHeader icon={FileText} title="ייבוא PDF" subtitle="העלה קובץ PDF לחילוץ הטקסט שלו" />

      <FileDropZone
        accept=".pdf"
        onFile={handlePdf}
        label="גרור קובץ PDF לכאן"
        sublabel="הטקסט יחולץ ויוצג למטה"
        icon={FileText}
      />

      {isLoading && (
        <div className="flex items-center justify-center gap-3 mt-8 text-muted-foreground">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span>מחלץ טקסט מה-PDF...</span>
        </div>
      )}

      {rawText && !isLoading && (
        <div className="mt-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">טקסט שחולץ</h2>
            <Button variant="outline" onClick={handleCopy} className="gap-2">
              <Copy className="w-4 h-4" /> העתק טקסט
            </Button>
          </div>
          <Card className="p-1">
            <Textarea
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              className="min-h-[400px] border-0 resize-none focus-visible:ring-0 text-sm font-mono leading-relaxed"
              placeholder="הטקסט שחולץ יופיע כאן..."
            />
          </Card>
        </div>
      )}
    </div>
  );
}